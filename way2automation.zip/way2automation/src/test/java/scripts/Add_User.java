package scripts;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Add_User {

	public static WebDriver driver;
	
	@BeforeClass
	public void navigate_To_UserTable()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\selenium drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.way2automation.com/angularjs-protractor/webtables/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//validation
		String Actual = driver.findElement(By.cssSelector(".btn.btn-link.pull-right")).getText();
		if(Actual.contains("Add User"))
		{
			System.out.println("user on the User List Table");
		}
		else {
			System.out.println("user is not on the User List Table");
		}
	}

	
	@Test(dataProvider="passingData")
	public void addUser(String fn, String ln, String un, String pwd, String cust, String rl, String email, String cell)
	{
		//click on add user
		driver.findElement(By.cssSelector(".btn.btn-link.pull-right")).click();
		//clear all the old data
		driver.findElement(By.name("FirstName")).clear();
		driver.findElement(By.name("LastName")).clear();
		driver.findElement(By.name("UserName")).clear();
		driver.findElement(By.name("Password")).clear();
		driver.findElement(By.name("Email")).clear();
		driver.findElement(By.name("Mobilephone")).clear();
		//passing values
		driver.findElement(By.name("FirstName")).sendKeys(fn);
		driver.findElement(By.name("LastName")).sendKeys(ln);
		driver.findElement(By.name("UserName")).sendKeys(un);
		driver.findElement(By.name("Password")).sendKeys(pwd);
		if(cust.equalsIgnoreCase("Company AAA"))
		{
		driver.findElement(By.xpath("//input[@value='16']")).click();
		}
		else if(cust.equalsIgnoreCase("Company BBB"))
		{
		driver.findElement(By.xpath("//input[@value='16']")).click();
		}
		Select role = new Select(driver.findElement(By.name("RoleId")));
		role.selectByVisibleText(rl);
		driver.findElement(By.name("Email")).sendKeys(email);
		driver.findElement(By.name("Mobilephone")).sendKeys(cell);
		driver.findElement(By.cssSelector(".btn.btn-success")).click();
		
		//validating user added or not
		
		List<WebElement> l1 = driver.findElements(By.xpath("//tbody/tr[@class='smart-table-data-row ng-scope']/td[1]"));
		
		for(WebElement fname:l1)
		{
			if(fname.getText().equals(fn))
			{
				System.out.println(fn+" Added successfully");
			}
		}
		
		//validating user is unique or not
		
		List<WebElement> l2 = driver.findElements(By.xpath("//tbody/tr[@class='smart-table-data-row ng-scope']/td[3]"));
		int count =0;
		for(WebElement user:l2)
		{
			if(user.getText().equals(un))
			{
				count = count+1;
			}
		}
		
		if(count==1)
		{
			System.out.println(un+" is unique");
		}
		else if(count>1)
		{
			System.out.println("Username found duplicate");
		}
		
	}
	
	@AfterClass
	public void close()
	{
		driver.close();
	}
	

	
	@DataProvider
	public Object[] passingData()
	{
		Object[][] obj = new Object[2][8];
		
		obj[0][0] = "FName1";
		obj[0][1] = "LName1";
		obj[0][2] = "User1";
		obj[0][3] = "Pass1";
		obj[0][4] = "Company AAA";
		obj[0][5] = "Admin";
		obj[0][6] = "admin@mail.com";
		obj[0][7] = "082555";
		
		obj[1][0] = "FName2";
		obj[1][1] = "LName2";
		obj[1][2] = "User2";
		obj[1][3] = "Pass2";
		obj[1][4] = "Company BBB";
		obj[1][5] = "Customer";
		obj[1][6] = "cusomter@mail.com";
		obj[1][7] = "083444";
		
		return obj;
		
	}
	
}
